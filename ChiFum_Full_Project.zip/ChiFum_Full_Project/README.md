# ChiFum Full Project

This archive contains three folders:
- chifum-backend (Node.js + Express + MongoDB)
- chifum-mobile-expo (React Native / Expo app)
- chifum-admin (React admin dashboard)

Open each folder and follow its README to get started. Copy `.env.example` to `.env` and fill in real keys before deploying.
