const axios = require('axios');
const PAYSTACK_SECRET = process.env.PAYSTACK_SECRET || '';

async function createPaystackRecipient(account){
  const res = await axios.post('https://api.paystack.co/transferrecipient', account, { headers: { Authorization: `Bearer ${PAYSTACK_SECRET}` } });
  return res.data;
}

async function paystackPayout(recipient_code, amount, narration){
  const res = await axios.post('https://api.paystack.co/transfer', { source: 'balance', amount: Math.round(amount * 100), recipient: recipient_code, reason: narration }, { headers: { Authorization: `Bearer ${PAYSTACK_SECRET}` } });
  return res.data;
}

module.exports = { createPaystackRecipient, paystackPayout };
