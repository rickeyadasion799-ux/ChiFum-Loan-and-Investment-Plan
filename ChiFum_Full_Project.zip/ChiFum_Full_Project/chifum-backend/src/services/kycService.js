const axios = require('axios');
const KEY = process.env.YOUVERIFY_KEY || '';

async function verifyBVN(bvn){
  if (!KEY) throw new Error('YOUVERIFY_KEY not configured');
  // This is an example; adapt to your provider's API
  const res = await axios.post('https://api.youverify.co/v1/bvn/verify', { bvn }, { headers: { Authorization: `Bearer ${KEY}` } });
  return res.data;
}

module.exports = { verifyBVN };
