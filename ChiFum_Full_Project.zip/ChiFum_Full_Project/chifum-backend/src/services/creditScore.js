module.exports = function score({ user, existingLoans = [] }){
  let s = 50;
  if (user.kycStatus === 'verified') s += 20;
  if (!existingLoans || existingLoans.length === 0) s += 15;
  const approved = s >= 60;
  const interestRate = approved ? 0.12 : 0.30;
  return { approved, interestRate };
};
