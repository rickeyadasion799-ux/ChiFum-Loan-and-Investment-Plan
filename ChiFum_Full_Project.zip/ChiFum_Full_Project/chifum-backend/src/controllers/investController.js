const Investment = require('../models/Investment');

exports.create = async (req, res) => {
  try {
    const { userId, planName, amount, ratePercent, days } = req.body;
    const startDate = new Date();
    const maturityDate = new Date(Date.now() + days*24*3600*1000);
    const inv = await Investment.create({ userId, planName, amount, ratePercent, startDate, maturityDate });
    res.json({ ok: true, investment: inv });
  } catch (err) { res.status(500).json({ ok: false, error: err.message }); }
};

exports.list = async (req, res) => {
  try {
    const investments = await Investment.find({ userId: req.query.userId });
    res.json({ ok: true, investments });
  } catch (err) { res.status(500).json({ ok: false, error: err.message }); }
};
