const Loan = require('../models/Loan');
const User = require('../models/User');
const score = require('../services/creditScore');

exports.apply = async (req, res) => {
  try {
    const { userId, amount, tenureDays, purpose } = req.body;
    const user = await User.findById(userId);
    if (!user) return res.status(404).json({ ok: false, error: 'User not found' });
    const existingLoans = await Loan.find({ userId });
    const decision = score({ user, existingLoans });
    const fee = Math.round(amount * 0.05);
    const interest = decision.interestRate;
    const loan = await Loan.create({ userId, amount, tenureDays, status: decision.approved ? 'approved' : 'pending', interestRate: interest, fee, dueDate: new Date(Date.now() + tenureDays*24*3600*1000), purpose });
    res.json({ ok: true, decision, loan });
  } catch (err) { res.status(500).json({ ok: false, error: err.message }); }
};

exports.list = async (req, res) => {
  try {
    const loans = await Loan.find({ userId: req.query.userId });
    res.json({ ok: true, loans });
  } catch (err) { res.status(500).json({ ok: false, error: err.message }); }
};
