const axios = require('axios');
const PAYSTACK_SECRET = process.env.PAYSTACK_SECRET || '';

exports.createRecipient = async (req, res) => {
  try {
    const body = {
      type: 'nuban',
      name: req.body.name,
      account_number: req.body.account_number,
      bank_code: req.body.bank_code,
      currency: 'NGN'
    };
    const result = await axios.post('https://api.paystack.co/transferrecipient', body, { headers: { Authorization: `Bearer ${PAYSTACK_SECRET}` } });
    return res.json(result.data);
  } catch (err) { return res.status(500).json({ ok: false, error: err.message }); }
};

exports.initiatePayout = async (req, res) => {
  try {
    const { recipient_code, amount, reason } = req.body;
    const result = await axios.post('https://api.paystack.co/transfer', { source: 'balance', amount: Math.round(amount * 100), recipient: recipient_code, reason }, { headers: { Authorization: `Bearer ${PAYSTACK_SECRET}` } });
    return res.json(result.data);
  } catch (err) { return res.status(500).json({ ok: false, error: err.message }); }
};

exports.paystackWebhook = async (req, res) => {
  // Note: in production you should verify signature using PAYSTACK_SECRET and raw body
  console.log('Paystack webhook received', req.body.event);
  res.sendStatus(200);
};
