const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const WalletTransactionSchema = new Schema({
  userId: { type: Schema.Types.ObjectId, ref: 'User' },
  type: { type: String, enum: ['credit','debit'] },
  amount: Number,
  meta: Schema.Types.Mixed
}, { timestamps: true });
module.exports = mongoose.model('WalletTransaction', WalletTransactionSchema);
