const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const InvestmentSchema = new Schema({
  userId: { type: Schema.Types.ObjectId, ref: 'User', required: true },
  planName: String,
  amount: Number,
  ratePercent: Number,
  startDate: Date,
  maturityDate: Date,
  status: { type: String, enum: ['active','matured','withdrawn'], default: 'active' }
}, { timestamps: true });
module.exports = mongoose.model('Investment', InvestmentSchema);
