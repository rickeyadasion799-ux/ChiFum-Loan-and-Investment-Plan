require('dotenv').config();
const express = require('express');
const helmet = require('helmet');
const cors = require('cors');
const mongoose = require('mongoose');

const auth = require('./controllers/authController');
const loan = require('./controllers/loanController');
const invest = require('./controllers/investController');
const payments = require('./controllers/paymentsController');

const app = express();
app.use(helmet());
app.use(cors());
app.use(express.json());

app.post('/api/auth/register', auth.register);
app.post('/api/auth/login', auth.login);

app.post('/api/loans/apply', loan.apply);
app.get('/api/loans', loan.list);

app.post('/api/investments/create', invest.create);
app.get('/api/investments', invest.list);

app.post('/api/payments/recipients', payments.createRecipient);
app.post('/api/payments/payout', payments.initiatePayout);
app.post('/api/payments/webhook', payments.paystackWebhook);

const PORT = process.env.PORT || 5000;
async function start(){
  await mongoose.connect(process.env.MONGO_URI || 'mongodb://localhost:27017/chifumdb');
  app.listen(PORT, ()=> console.log('ChiFum API listening on', PORT));
}
start();
