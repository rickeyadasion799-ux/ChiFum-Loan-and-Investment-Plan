import React from 'react';

export default function Admin(){
  return (
    <div style={{padding:20}}>
      <h1>ChiFum Admin</h1>
      <div style={{display:'grid',gridTemplateColumns:'repeat(3,1fr)',gap:12,marginTop:12}}>
        <div style={{border:'1px solid #eee',padding:12}}>Users</div>
        <div style={{border:'1px solid #eee',padding:12}}>Loans</div>
        <div style={{border:'1px solid #eee',padding:12}}>Investments</div>
      </div>
    </div>
  );
}
