import React from 'react';
import { SafeAreaView, Text, TouchableOpacity } from 'react-native';

export default function Dashboard({ route, navigation }){
  const user = route.params?.user || { name: 'User' };
  return (
    <SafeAreaView style={{flex:1,padding:20}}>
      <Text style={{fontSize:20,fontWeight:'700'}}>Welcome back, {user.name}</Text>
      <TouchableOpacity style={{marginTop:20,backgroundColor:'#4f046a',padding:12,borderRadius:8}} onPress={()=>navigation.replace('Landing')}><Text style={{color:'#fff'}}>Logout</Text></TouchableOpacity>
    </SafeAreaView>
  );
}
