import React from 'react';
import { View, Text, TouchableOpacity, SafeAreaView } from 'react-native';
export default function Landing({ navigation }){
  return (
    <SafeAreaView style={{flex:1,padding:20}}>
      <Text style={{fontSize:28,fontWeight:'700'}}>ChiFum</Text>
      <Text style={{marginTop:8}}>Loan & Investment Application</Text>
      <TouchableOpacity onPress={()=>navigation.navigate('Auth',{mode:'register'})} style={{marginTop:20,backgroundColor:'#4f046a',padding:12,borderRadius:8}}>
        <Text style={{color:'#fff'}}>Get Started</Text>
      </TouchableOpacity>
      <TouchableOpacity onPress={()=>navigation.navigate('Auth',{mode:'login'})} style={{marginTop:10,padding:12,borderRadius:8,borderWidth:1}}>
        <Text>Sign In</Text>
      </TouchableOpacity>
    </SafeAreaView>
  );
}
