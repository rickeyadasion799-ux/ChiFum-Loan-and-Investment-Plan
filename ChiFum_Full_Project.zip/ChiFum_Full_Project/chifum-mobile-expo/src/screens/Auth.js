import React, {useState} from 'react';
import { SafeAreaView, Text, TextInput, TouchableOpacity, ScrollView } from 'react-native';
import { login, register } from '../services/api';

export default function Auth({ route, navigation }){
  const mode = route.params?.mode || 'login';
  const [form,setForm]=useState({ name:'', email:'', phone:'', password:'', nin:'', bvn:'' });
  const [loading,setLoading]=useState(false);
  const submit = async ()=>{
    setLoading(true);
    try{
      if(mode==='login'){
        const res = await login(form.email, form.password);
        if(res.token) navigation.replace('Dashboard', { user: { name: form.email } });
      }else{
        const res = await register(form);
        if(res.ok) navigation.replace('Dashboard', { user: { name: form.name } });
      }
    }catch(e){ alert(e.message) }
    setLoading(false);
  };
  return (
    <SafeAreaView style={{flex:1,padding:20}}>
      <ScrollView>
        <Text style={{fontSize:20,fontWeight:'700'}}>{mode==='login'?'Sign In':'Create an account'}</Text>
        {mode==='register' && <TextInput placeholder='Full name' value={form.name} onChangeText={t=>setForm({...form,name:t})} style={{borderWidth:1,marginTop:10,padding:10}} />}
        <TextInput placeholder='Email' keyboardType='email-address' value={form.email} onChangeText={t=>setForm({...form,email:t})} style={{borderWidth:1,marginTop:10,padding:10}} />
        {mode==='register' && <TextInput placeholder='Phone' value={form.phone} onChangeText={t=>setForm({...form,phone:t})} style={{borderWidth:1,marginTop:10,padding:10}} />}
        <TextInput placeholder='Password' secureTextEntry value={form.password} onChangeText={t=>setForm({...form,password:t})} style={{borderWidth:1,marginTop:10,padding:10}} />
        <TouchableOpacity onPress={submit} style={{backgroundColor:'#4f046a',padding:12,borderRadius:8,marginTop:16}} disabled={loading}><Text style={{color:'#fff'}}>{loading?'Please wait...':(mode==='login'?'Login':'Create account')}</Text></TouchableOpacity>
      </ScrollView>
    </SafeAreaView>
  );
}
