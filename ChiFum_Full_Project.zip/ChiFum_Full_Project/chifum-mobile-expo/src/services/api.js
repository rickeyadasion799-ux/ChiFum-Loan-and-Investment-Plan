import axios from 'axios';
import * as SecureStore from 'expo-secure-store';

const API_BASE = 'http://10.0.2.2:5000'; // use emulator/localhost mapping or your server URL

const api = axios.create({ baseURL: API_BASE, timeout: 15000 });

api.interceptors.request.use(async config=>{
  const token = await SecureStore.getItemAsync('chifum_token');
  if(token) config.headers.Authorization = `Bearer ${token}`;
  return config;
});

export async function login(email,password){
  const res = await api.post('/api/auth/login', { email, password });
  if(res.data?.token) await SecureStore.setItemAsync('chifum_token', res.data.token);
  return res.data;
}

export async function register(payload){
  const res = await api.post('/api/auth/register', payload);
  return res.data;
}

export async function applyLoan(payload){ const res = await api.post('/api/loans/apply', payload); return res.data; }
export async function createInvestment(payload){ const res = await api.post('/api/investments/create', payload); return res.data; }

export default api;
